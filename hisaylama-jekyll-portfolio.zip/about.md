---
layout: page
title: About
permalink: /about/
---

I’m an experimental physicist working across **soft‑matter**, **statistical physics**, and **machine learning**. I like building small, practical tools that help extract structure, dynamics and function from messy data — from AFM height profiles to Monte Carlo simulations and molecular graph learning.

This site is a living portfolio. For code, see my [GitHub](https://github.com/{{ site.github_username }}), and for ML notebooks and competitions, see [Kaggle](https://www.kaggle.com/{{ site.kaggle_username }}).
