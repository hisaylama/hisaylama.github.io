---
layout: default
title: Home
---

<style>
/* Lightweight card layout that works with the minimal theme */
.cards {display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px;margin:0;padding:0;list-style:none}
.card{border:1px solid #e6e6e6;border-radius:12px;padding:14px;background:#fff}
.card h3{margin:.2rem 0 .4rem 0;font-size:1.05rem}
.badges{display:flex;gap:8px;flex-wrap:wrap;margin-top:.5rem}
.badge{font-size:.75rem;padding:.2rem .5rem;border:1px solid #e6e6e6;border-radius:999px;background:#f7f7f7}
.hero{display:flex;gap:18px;align-items:flex-start;flex-wrap:wrap;margin:6px 0 18px 0}
.hero img{width:84px;height:84px;border-radius:12px;border:1px solid #e6e6e6}
.hero .text{flex:1;min-width:260px}
.small{color:#666}
</style>

<div class="hero">
  <img src="{{ '/assets/img/avatar.svg' | relative_url }}" alt="Profile avatar">
  <div class="text">
    <h1>Hi, I'm <strong>Hisay Lama</strong>.</h1>
    <p class="small">Experimental soft‑matter physics · statistical physics · quantitative image analysis · machine learning.</p>
    <p>On this page you’ll find selected projects, publications-in-progress, and links. I’m currently exploring intermittent search strategies (MFPT scaling), sentiment-driven market prediction, and molecular graph learning.</p>
    <p>
      <a href="https://github.com/{{ site.github_username }}">GitHub</a> ·
      <a href="https://www.kaggle.com/{{ site.kaggle_username }}">Kaggle</a> ·
      <a href="{{ site.linkedin_url }}">LinkedIn</a> ·
      <a href="mailto:{{ site.email }}">Email</a>
    </p>
  </div>
</div>

## Featured Projects

<ul class="cards">
  {%- for p in site.data.projects -%}
  <li class="card">
    <h3><a href="{{ p.link }}">{{ p.name }}</a></h3>
    <p>{{ p.description }}</p>
    <div class="badges">
      {%- for t in p.tags -%}
      <span class="badge">{{ t }}</span>
      {%- endfor -%}
    </div>
  </li>
  {%- endfor -%}
</ul>

## Publications & Preprints
- _Add items in_ `/_data/publications.yml` _and they’ll render below._

{%- if site.data.publications and site.data.publications.size > 0 -%}
{%- for pub in site.data.publications -%}
- **{{ pub.authors }}**, “_{{ pub.title }}_,” {{ pub.venue }} ({{ pub.year }}). {%- if pub.url %} [link]({{ pub.url }}){%- endif -%}
{%- endfor -%}
{%- else -%}
- _Coming soon._
{%- endif -%}

## Talks & Teaching
- Intermittent search strategies: MFPT scaling (seminar)
- Quantitative imaging of soft interfaces (group meeting)
- Computational Finance (self‑designed syllabus)

## Contact
- **Email:** <a href="mailto:{{ site.email }}">{{ site.email }}</a><br/>
- **GitHub:** <a href="https://github.com/{{ site.github_username }}">@{{ site.github_username }}</a><br/>
- **Kaggle:** <a href="https://www.kaggle.com/{{ site.kaggle_username }}">/ {{ site.kaggle_username }}</a><br/>
- **LinkedIn:** <a href="{{ site.linkedin_url }}">{{ site.linkedin_url }}</a>
