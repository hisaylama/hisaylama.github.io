# Hisay Lama — GitHub Pages Portfolio (Jekyll Minimal)

This is a ready-to-deploy portfolio using **`jekyll-theme-minimal`**.

## Quick start
1. Create a repo called **`hisaylama.github.io`** (or your username).
2. Upload all files in this folder to the repo root.
3. Go to **Settings → Pages** and ensure the site is published from the `main` branch (root).
4. Visit `https://USERNAME.github.io`.

## Customize
- Edit `_config.yml` (title, description, links).
- Put your projects in `/_data/projects.yml`.
- Edit `index.md`, `about.md`, and `projects.md` as you like.
- Replace `assets/img/avatar.svg` with your own image if desired.

## Local preview (optional)
If you want to test locally, install Ruby and run:
```bash
gem install bundler jekyll
jekyll serve
```
Then open `http://localhost:4000`.
