---
layout: page
title: Projects
permalink: /projects/
---

Below are all projects defined in `/_data/projects.yml`.

<ul class="cards">
  {%- for p in site.data.projects -%}
  <li class="card">
    <h3><a href="{{ p.link }}">{{ p.name }}</a></h3>
    <p>{{ p.description }}</p>
    <div class="badges">
      {%- for t in p.tags -%}
      <span class="badge">{{ t }}</span>
      {%- endfor -%}
    </div>
  </li>
  {%- endfor -%}
</ul>
